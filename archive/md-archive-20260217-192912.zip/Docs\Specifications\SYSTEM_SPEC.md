📘 SYSTEM_SPEC v2
Virtual Store–Driven Theme Development System
Version: 2.0
Status: Approved / Implementation-Ready
1️⃣ تعريف النظام
الاسم

Virtual Theme Development Runtime (VTDR)

التعريف

نظام تطوير وتشغيل بيئة افتراضية تحاكي سلوك تخصيص وتشغيل الثيمات داخل سلة، بهدف:

تطوير الثيمات

تخصيصها

معاينتها

اختبارها

إصدار نسخ منها

دون الحاجة إلى متجر ديمو أو اشتراك أثناء مرحلة التطوير.

2️⃣ الهدف الأساسي

إنشاء بيئة تطوير:

تعتمد على Store-Driven State

تستخدم Schema-Driven UI

تبني Runtime Context مطابق لعقد الثيم

تنتج Preview مطابق لما سيظهر داخل سلة بعد التركيب

3️⃣ النطاق (Scope)

النظام يشمل:

إدارة الثيمات

إدارة إصدارات الثيم

إدارة متجر افتراضي

إدارة مكونات الثيم

إدارة الإعدادات عبر Schema

بناء Runtime Context

عرض Live Preview

تصدير نسخة جاهزة للتركيب

النظام لا يشمل:

تشغيل متجر فعلي

مدفوعات

طلبات

تكامل API مع سلة أثناء التطوير

4️⃣ المفاهيم الأساسية
4.1 Theme

كيان يحتوي على:

Metadata

Capabilities

Components

Settings Schema

Versions

4.2 Theme Version

نسخة محددة من الثيم تحتوي على:

ملفات القالب

تعريف Schema

تعريف Capabilities

رقم إصدار

4.3 Virtual Store

كيان يمثل متجرًا افتراضيًا يحتوي على:

Store State

Data Content

Active Theme Version

Scenario

4.4 Component Registry

سجل مركزي يحتوي على:

component_key

path

schema

capabilities requirements

4.5 Runtime Context

كائن ناتج عن دمج:

Theme Capabilities

Store State

Selected Scenario

Bound Data

5️⃣ المعمارية العامة
5.1 الطبقات
A — UI Layer

إدارة الحالة

عرض الإعدادات

تشغيل المعاينة

إدارة المتاجر الافتراضية

B — State Layer

Active Theme

Active Version

Store State

Selected Scenario

C — Runtime Layer

Context Builder

Component Resolver

Schema Interpreter

Theme Renderer

D — Storage Layer

Theme Files

Store State

Data Content

Version Snapshots

6️⃣ العقود الرسمية
6.1 Theme Capabilities Contract

كل ثيم يعلن قدراته.
الواجهة تعرض فقط ما هو مدعوم.

6.2 Schema-Driven Settings Contract

جميع الإعدادات تُولد ديناميكيًا من Schema.

6.3 Store-Owned State Contract

الثيم لا يملك حالة.
جميع القيم محفوظة في Store State.

6.4 Component Path Registry Contract

كل مكون مرتبط بمسار ثابت داخل الثيم.
لا يُسمح بحقن خارج هذا المسار.

6.5 Runtime Context Contract

المعاينة تُبنى فقط من Runtime Context.
Preview = Pure(Context)

6.6 Context Isolation Contract

كل Virtual Store معزول.
لا مشاركة ضمنية للحالة.

7️⃣ واجهة النظام
7.1 Global Layout
System Shell
├─ Sidebar
├─ Main Workspace
└─ Inspector Panel

7.2 Sidebar

Themes

Versions

Virtual Stores

Scenarios

Pages

Components

Export

7.3 Main Workspace

يتغير حسب السياق:

Live Preview

Page Composer

Content Editor

7.4 Inspector Panel

Theme Settings

Component Settings

Data Binding

Capabilities Info

8️⃣ دورة التشغيل

اختيار Theme Version

اختيار Virtual Store

تحميل Store State

بناء Runtime Context

تشغيل Theme Renderer

عرض Live Preview

تعديل الإعدادات

تحديث State

إعادة بناء Context

تحديث Preview

9️⃣ نظام الإصدارات
9.1 Versioning Rules

كل Theme يمكن أن يحتوي على عدة Versions

كل Version مستقل في:

Files

Schema

Capabilities

يمكن ربط Virtual Store بأي Version

9.2 Snapshot System

عند كل حفظ:

يتم حفظ Snapshot

يمكن الرجوع لأي نسخة

يمكن مقارنة نسختين

🔟 إدارة البيانات
10.1 Content Data

يشمل:

Products

Categories

Reviews

Media

Custom Fields

البيانات مرتبطة بالـ Virtual Store وليس بالثيم.

10.2 Data Binding

Component يمكن ربطه بـ:

مجموعة منتجات

تصنيف

بيانات مخصصة

مصدر ديناميكي

11️⃣ نظام المعاينة
11.1 خصائص المعاينة

Instant Rebuild

Scenario Switching

Viewport Switching

Isolated Rendering

12️⃣ التصدير
12.1 Export Process

اختيار Theme Version

تجميد Schema

تجميد Capabilities

تصدير الملفات فقط

لا يتم تصدير Store State

13️⃣ قابلية التوسع

النظام يدعم:

تعدد الثيمات

تعدد الإصدارات

تعدد المتاجر الافتراضية

تعدد السيناريوهات

تعدد بيئات المعاينة

14️⃣ قابلية التوسعة المستقبلية

يمكن إضافة:

Marketplace داخلي

مقارنة نسخ بصرية

CI للثيمات

اختبارات تلقائية للعقود

دعم أكثر من منصة

15️⃣ تعريف النجاح

النظام يُعتبر ناجحًا إذا:

الثيم الناتج يعمل في سلة دون تعديل

المعاينة تعكس النتيجة الفعلية

لا يوجد إعداد غير مدعوم يظهر في الواجهة

يمكن تبديل المتجر أو السيناريو فورًا

لا يوجد اعتماد على متجر ديمو أثناء التطوير

16️⃣ المبدأ الحاكم

النظام لا يُحاكي سلة كمنصة تجارة
بل يُحاكي بيئة تشغيل الثيم فقط
ضمن عقد ثابت وقابل للتحقق.

الحالة الحالية

SYSTEM_SPEC v2
✔️ مكتمل
✔️ متسق
✔️ قابل للتنفيذ
✔️ مبني على عقود رسمية
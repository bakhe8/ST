DATA_SCHEMA_SPEC

Virtual Commerce Data Schema for Theme Development Runtime

1. الغاية (Purpose)

يوفّر هذا المخطط بنية بيانات موحّدة تمثل محتوى متجر افتراضي يُستخدم أثناء:

تطوير الثيمات

تصميم الواجهات

اختبار سلوك الكومبوننتات

محاكاة إعدادات المتاجر المختلفة

بحيث تكون البيانات:

منفصلة تمامًا عن الثيم

قابلة لإعادة الاستخدام

قابلة للتبديل بين سيناريوهات مختلفة

مطابقة منطقيًا لما تتعامل معه ثيمات سلة فعليًا

2. المبادئ الأساسية (Core Principles)

البيانات مستقلة عن الثيم

البيانات لا تفترض شكل العرض

البيانات تدعم تنوع المنتجات والكومبوننتات

البيانات قابلة للتركيب (Composable)

البيانات قابلة للتبديل حسب الـ Profile / Scenario

3. التقسيم العام (High-Level Structure)
DataSchema {
  store
  catalogs
  products
  collections
  content
  users
  interactions
}


كل قسم مستقل منطقيًا، لكنه قابل للربط.

4. Store (بيانات المتجر)

يمثل هوية المتجر وسياقه العام.

Store {
  id: string
  name: string
  locale: string
  currency: string
  branding: {
    logo
    colors
    fonts
  }
}

5. Catalogs (التصنيفات والبنية التجارية)
Catalog {
  id: string
  type: "category" | "brand" | "tag"
  title
  parentId?
  metadata?
}


يدعم:

شجرة تصنيفات

تصنيفات متعددة للمنتج الواحد

ربط حر بالكومبوننتات

6. Products (المنتجات – النواة الأهم)

المنتج كائن مرن، وليس قالبًا ثابتًا.

Product {
  id: string
  title
  description
  price
  media: Media[]
  attributes: Attribute[]
  variants: Variant[]
  relations: ProductRelation[]
}

6.1 Attributes (مواصفات ديناميكية)
Attribute {
  key: string
  type: "text" | "number" | "boolean" | "list" | "table"
  value: any
}


مثال:
منتج يحتوي جدول مواصفات
منتج آخر يحتوي ألوان فقط
منتج ثالث يحتوي ملفات تحميل

6.2 Variants
Variant {
  id
  options: Record<string, string>
  priceDelta?
  media?
}

7. Collections (تجميعات العرض)

تمثل ما تختاره أنت من الواجهة لعرضه داخل ثيم معين.

Collection {
  id: string
  source: "manual" | "rule"
  items: Product[]
  rules?
}


تُستخدم في:

سلايدر منتجات

منتجات مميزة

أقسام حسب الثيم

8. Content (المحتوى النصي والبصري)

يمثل كل ما هو غير منتج.

ContentItem {
  id
  type: "text" | "image" | "video" | "testimonial"
  data
  context?
}


أمثلة:

نصوص وصف

آراء عملاء

بانرات

صور تعريفية

9. Users (شخصيات افتراضية)
User {
  id
  name
  role: "visitor" | "customer"
}


تُستخدم لمحاكاة:

التعليقات

التقييمات

التفاعلات

10. Interactions (التفاعل والسلوك)
Interaction {
  type: "review" | "rating" | "wishlist" | "cart"
  userId
  targetId
  payload
}


يمثل:

تعليق زائر

تقييم منتج

إضافة لقائمة أمنيات

11. السيناريوهات (Profiles / Scenarios)

الـ Scenario هو تجميعة مرجعية تربط كل ما سبق.

DataScenario {
  id: string
  store
  products
  collections
  content
  interactions
}


🎯 هذا هو ما يختاره المطوّر من الواجهة

12. علاقة DATA_SCHEMA_SPEC بالثيم

الثيم يقرأ فقط

الثيم لا يقرر شكل البيانات

الثيم يقرر فقط:

ماذا يستخدم

وكيف يعرضه

13. التخزين (Storage Semantics)

كل كيان معرف بـ ID

كل كيان قابل للتحميل الجزئي

كل سيناريو قابل للحفظ والاستدعاء

14. التكامل مع UI / Runtime

UI:

تبني وتحرر DataScenario

Runtime:

يمرر DataScenario إلى الثيم

Theme:

يستهلك البيانات دون معرفة مصدرها

15. النتيجة النهائية

هذا المخطط يسمح للنظام أن:

يعرض نفس المنتج بطرق مختلفة حسب الثيم

يغيّر سلوك الكومبوننت حسب السيناريو

يدعم عدد غير محدود من الثيمات

يحاكي سلة بدقة من ناحية العقد لا التنفيذ